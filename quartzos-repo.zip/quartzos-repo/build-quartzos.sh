#!/usr/bin/env bash
# QuartzOS 1.0 "Rose" - ISO build script (Debian live-build + XFCE + Firefox ESR)
# Run on a Debian/Ubuntu machine:  sudo ./build-quartzos.sh
# Needs ~15 GB free disk and an internet connection. Output: quartzos-1.0-amd64.iso
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Run as root: sudo $0"; exit 1; }

apt-get update && apt-get install -y live-build debootstrap xorriso squashfs-tools

WORK=quartzos-build
rm -rf "$WORK" && mkdir "$WORK" && cd "$WORK"

lb config \
  --distribution bookworm \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --archive-areas "main contrib non-free-firmware" \
  --iso-application "QuartzOS" \
  --iso-publisher "QuartzOS Project" \
  --iso-volume "QuartzOS 1.0" \
  --bootappend-live "boot=live components quiet splash username=quartz hostname=quartz locales=en_US.UTF-8 keyboard-layouts=us"

# ---------- packages ----------
cat > config/package-lists/quartz.list.chroot <<'EOF'
# desktop
xfce4
xfce4-goodies
lightdm
lightdm-gtk-greeter
network-manager-gnome
pulseaudio
pavucontrol
# browser: Firefox ESR + language packs for all 10 QuartzOS languages
firefox-esr
firefox-esr-l10n-es-es
firefox-esr-l10n-fr
firefox-esr-l10n-de
firefox-esr-l10n-pt-br
firefox-esr-l10n-ru
firefox-esr-l10n-ja
firefox-esr-l10n-zh-cn
firefox-esr-l10n-ar
firefox-esr-l10n-hi-in
# system language support and fonts
locales
console-setup
fonts-noto
fonts-noto-cjk
fonts-noto-color-emoji
# apps
thunar
mousepad
xfce4-terminal
galculator
file-roller
# installer
calamares
calamares-settings-debian
EOF

# ---------- Firefox: HTTPS-only, QuartzOS home page, default browser ----------
mkdir -p config/includes.chroot/usr/lib/firefox-esr/distribution
cat > config/includes.chroot/usr/lib/firefox-esr/distribution/policies.json <<'EOF'
{
  "policies": {
    "DisableTelemetry": true,
    "OverrideFirstRunPage": "",
    "Homepage": { "URL": "https://duckduckgo.com", "StartPage": "homepage", "Locked": false },
    "Preferences": {
      "dom.security.https_only_mode": { "Value": true, "Status": "default" },
      "browser.startup.homepage": { "Value": "https://duckduckgo.com", "Status": "default" }
    }
  }
}
EOF

# ---------- QuartzOS branding ----------
mkdir -p config/includes.chroot/etc
cat > config/includes.chroot/etc/os-release <<'EOF'
PRETTY_NAME="QuartzOS 1.0 (Rose)"
NAME="QuartzOS"
VERSION_ID="1.0"
VERSION="1.0 (Rose)"
ID=quartzos
ID_LIKE=debian
HOME_URL="https://quartzos.example"
EOF
echo "QuartzOS 1.0 (Rose) \\n \\l" > config/includes.chroot/etc/issue
echo "quartz" > config/includes.chroot/etc/hostname

# ---------- hooks ----------
mkdir -p config/hooks/live
cat > config/hooks/live/0100-quartz.hook.chroot <<'EOF'
#!/bin/sh
set -e
# make Firefox the default web browser
update-alternatives --set x-www-browser /usr/bin/firefox-esr || true
update-alternatives --set gnome-www-browser /usr/bin/firefox-esr || true
# enable the ten QuartzOS locales
for l in en_US es_ES fr_FR de_DE pt_BR ru_RU ja_JP zh_CN ar_SA hi_IN; do
  sed -i "s/^# *\($l.UTF-8 UTF-8\)/\1/" /etc/locale.gen
done
locale-gen
# autologin-free LightDM greeter with the QuartzOS name
mkdir -p /etc/lightdm/lightdm-gtk-greeter.conf.d
printf '[greeter]\ntheme-name=Adwaita-dark\nclock-format=%%H:%%M\n' > /etc/lightdm/lightdm-gtk-greeter.conf.d/quartz.conf
EOF
chmod +x config/hooks/live/0100-quartz.hook.chroot

# ---------- build ----------
lb build
mv live-image-amd64.hybrid.iso ../quartzos-1.0-amd64.iso
echo "Done: quartzos-1.0-amd64.iso"
echo "Test it:  qemu-system-x86_64 -m 4G -enable-kvm -cdrom quartzos-1.0-amd64.iso"
echo "Default login: user 'user' / password 'live' (Debian live default)."
